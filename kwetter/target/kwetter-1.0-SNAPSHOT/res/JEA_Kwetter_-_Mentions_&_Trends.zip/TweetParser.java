/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import domain.Mention;
import domain.Trend;
import domain.Tweet;
import domain.User;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.ejb.Stateless;
import javax.inject.Inject;
import service.UserService;

/**
 *
 * @author Jelle
 */
@Stateless
public class TweetParser {

    @Inject
    private UserService userService;

    /**
     * Finds all Trends in a given Tweet.
     *
     * @param tweet The Tweet which will be parsed.
     * @return A list of Trends.
     */
    public ArrayList<Trend> findHashtags(Tweet tweet) {
        ArrayList<Trend> trends = new ArrayList<>();

        String content = tweet.getText();
        String pattern = "(?:\\s|\\A|^)[##]+([A-Za-z0-9-_]+)";

        Pattern r = Pattern.compile(pattern);

        Matcher m = r.matcher(content);
        while (m.find()) {
            String hashtag = m.group(0).trim();
            Trend tempTrend = new Trend(hashtag);

            if (trends.contains(tempTrend)) {
                int trendsIndex = trends.indexOf(tempTrend);
                trends.get(trendsIndex).setHashCount(tempTrend.getHashCount() + 1);
            } else {
                Trend trend = new Trend(hashtag, tweet);
                trend.setFirstUsed(tweet.getDate());
                trends.add(trend);
            }
        }

        return trends;
    }

    /**
     * Finds all Mentions in a given Tweet.
     *
     * @param tweet The Tweet which will be parsed.
     * @return A list of Mentions.
     */
    public ArrayList<Mention> findMentions(Tweet tweet) {
        ArrayList<Mention> mentions = new ArrayList<>();

        String content = tweet.getText();
        String pattern = "@([a-zA-Z0-9]+)";

        Pattern r = Pattern.compile(pattern);

        Matcher m = r.matcher(content);
        while (m.find()) {
            User foundUser = userService.findByUsername(m.group(0).replace("@", ""));
            if (foundUser != null) {
                mentions.add(new Mention(tweet, foundUser));
            }
        }

        return mentions;
    }

}
