/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Jelle
 */
//@Entity
@XmlRootElement
public class Trend implements Serializable {

    //@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String hashtag;

    private int hashCount;

    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date firstUsed;

    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date lastUsed;

    @OneToMany
    private Collection<Tweet> tweets;

    public Trend() {
    }

    public Trend(String hashtag) {
        this.hashtag = hashtag;
        this.tweets = new ArrayList<>();
        this.hashCount = 1;
        this.lastUsed = new Date();
        this.firstUsed = new Date();
    }

    public Trend(String hashtag, int hashCount, Tweet tweet) {
        this.tweets = new ArrayList<>();
        this.hashtag = hashtag;
        this.hashCount = hashCount;
        this.firstUsed = new Date();
        this.lastUsed = new Date();
        this.tweets.add(tweet);
    }

    public Trend(String hashtag, Tweet tweet) {
        this.tweets = new ArrayList<>();
        this.hashtag = hashtag;
        this.hashCount = 1;
        this.firstUsed = new Date();
        this.lastUsed = new Date();
        this.tweets.add(tweet);
    }

    public Trend(String hashtag, int hashCount) {
        this.hashtag = hashtag;
        this.hashCount = hashCount;
    }

    public String getHashtag() {
        return hashtag;
    }

    public void setHashtag(String hashtag) {
        this.hashtag = hashtag;
    }

    public int getHashCount() {
        return hashCount;
    }

    public void setHashCount(int hashCount) {
        this.hashCount = hashCount;
    }

    public Date getFirstUsed() {
        return firstUsed;
    }

    public void setFirstUsed(Date firstUsed) {
        this.firstUsed = firstUsed;
    }

    public Date getLastUsed() {
        return lastUsed;
    }

    public void setLastUsed(Date lastUsed) {
        this.lastUsed = lastUsed;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @XmlTransient
    public Collection<Tweet> getTweets() {
        return tweets;
    }

    public void setTweets(Collection<Tweet> tweets) {
        this.tweets = tweets;
    }

    public void addTweet(Tweet tweet) {
        if (!this.tweets.contains(tweet)) {
            this.tweets.add(tweet);
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Trend other = (Trend) obj;
        return Objects.equals(this.hashtag, other.hashtag);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.hashtag);
        return hash;
    }
}
