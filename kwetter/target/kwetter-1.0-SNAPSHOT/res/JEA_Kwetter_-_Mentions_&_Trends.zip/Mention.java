/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Jelle
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "mention.findByUsername", query = "SELECT m FROM Mention m WHERE m.user.username = :username")
    ,
    @NamedQuery(name = "mention.findById", query = "SELECT m from Mention m WHERE m.id = :id")})
@XmlRootElement
public class Mention implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @OneToOne
    private Tweet tweet;

    @ManyToOne
    private User user;

    public Mention() {
    }

    public Mention(Tweet tweet, User user) {
        this.tweet = tweet;
        this.user = user;
        user.addMention(this);
    }

    @XmlTransient
    public Tweet getTweet() {
        return tweet;
    }

    public void setTweet(Tweet tweet) {
        this.tweet = tweet;
    }

    @XmlTransient
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
